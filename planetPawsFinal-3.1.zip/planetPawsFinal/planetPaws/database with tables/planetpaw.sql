-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307:3307
-- Generation Time: Jul 13, 2024 at 09:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `planetpaw`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(6) UNSIGNED NOT NULL,
  `pet_age` int(11) NOT NULL,
  `health_issue` varchar(100) NOT NULL,
  `vet_name` varchar(30) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `pet_age`, `health_issue`, `vet_name`, `appointment_date`, `appointment_time`) VALUES
(1, 3, 'behaviour', 'karin', '2024-07-23', '02:55:00'),
(2, 2, 'behaviour', 'meher', '2024-07-11', '20:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `price` int(11) NOT NULL,
  `image` blob NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(0, 'mew', 5, 0x636174322e6a7067, 1),
(0, 'sim', 2, 0x646f67322e6a706567, 1);

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `message` text DEFAULT NULL,
  `donation_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `name`, `email`, `amount`, `message`, `donation_date`) VALUES
(1, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 10.00, 'wweffqe', '2024-06-29 06:53:58'),
(2, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:19:47'),
(3, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:21:46'),
(4, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:22:02'),
(5, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:23:52'),
(6, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:25:39'),
(7, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:26:13'),
(8, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:26:54'),
(9, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:27:05'),
(10, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:27:14'),
(11, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:27:23'),
(12, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'fefergt34gtgh', '2024-06-29 07:28:11'),
(14, 'Rowzatul Zannath Prerona', 'rowzatulzannathprerona@gmail.com', 100.00, 'nekjfnjerfnerjgerjgejr', '2024-06-29 15:44:01'),
(15, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 1000.00, 'jefhejrfhreufhuer', '2024-06-30 03:07:43'),
(16, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 1000.00, 'jvbejrverhgbh', '2024-06-30 03:08:57'),
(17, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 200.00, 'enfdejfnerjferj', '2024-06-30 03:45:44'),
(18, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 200.00, 'enfdejfnerjferj', '2024-06-30 03:45:50'),
(19, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 10000.00, 'wydgeyfgeryfgeyrf', '2024-06-30 04:10:52'),
(20, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 10000.00, 'private donate', '2024-06-30 07:43:45'),
(21, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 1000.00, 'jdbjewbjwfwjf', '2024-07-08 14:39:02'),
(22, 'Mysha Momo', 'myshamomo2001@gmail.com', 100000.00, 'private donate', '2024-07-09 05:49:13'),
(23, 'Mysha Momo', 'myshamomo2001@gmail.com', 1000.00, 'Private Donation', '2024-07-09 09:26:38'),
(24, 'Mysha Momo', 'mysha.cse.20210204016@aust.edu', 5000.00, 'Private Care Company', '2024-07-09 09:31:28'),
(25, 'Mysha Momo', 'njkuh@gmail.com', 100.00, 'mpkouibutfgy', '2024-07-12 17:35:02'),
(26, ' knm ', 'knm@gmail.com', 100.00, ' kjnkm ', '2024-07-12 17:35:42');

-- --------------------------------------------------------

--
-- Table structure for table `encyclopedia`
--

CREATE TABLE `encyclopedia` (
  `S_no` int(11) NOT NULL,
  `Disease` varchar(50) NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Info` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `encyclopedia`
--

INSERT INTO `encyclopedia` (`S_no`, `Disease`, `Detail`, `Info`) VALUES
(1, 'Rabies', 'is a fatal viral disease that can affect any mammal, although the close relationship of dogs with humans makes canine rabies a zoonotic concern.', 'Vaccination of dogs for rabies is commonly required by law.'),
(2, 'Parvovirus', 'is a sometimes fatal gastrointestinal infection that mainly affects puppies.', 'It occurs worldwide.'),
(3, 'coronavirus', 'is a gastrointestinal disease that is usually asymptomatic or with mild clinical signs.', 'The signs are worse in puppies.'),
(4, 'distemper', 'is an often fatal infectious disease that mainly has respiratory and neurological signs.', 'Vaccination is commonly required by law. '),
(5, 'influenza', 'is a newly emerging infectious respiratory disease', 'Up to 80 percent of dogs infected will have symptoms, but the mortality rate is only 5 to 8 percent.'),
(6, 'hepatitis', 'is a sometimes fatal infectious disease of the liver.', ' It occurs worldwide.'),
(7, 'herpesvirus', 'is an infectious disease that is a common cause of death in puppies less than three weeks old.', 'The signs are worse in puppies.'),
(8, 'lyme disease', 'Symptoms in dogs include acute arthritis, anorexia and lethargy.', 'There is no rash as is typically seen in humans.'),
(9, 'clostridium', 'species are a potential cause of diarrhea in dogs.', 'The signs are worse in puppies.'),
(10, 'mites', 'Symptoms include itching, inflammation, and black debris in the ear.', 'Symptoms include itching, inflammation, and black debris in the ear.'),
(11, 'rage syndrome', 'is a rare inherited seizure disorder characterized by explosive aggression and focal neurologic symptoms.', 'the mortality rate is only 5 to 8 percent.'),
(12, 'epilepsy', 'The most common sign recurring generalized seizures beginning at a young adult age.', 'This is a rare case for animals.'),
(13, 'Polyneuropathy', 'is a collection of peripheral nerve disorders that often are breed-related in dogs.', 'mainly has respiratory and neurological signs.'),
(14, 'cognitive dysfunction', 'is a progressive disease occurring in older dogs', 'is similar to the dementia which occurs in humans with Alzheimer\'s disease.'),
(15, 'Coonhound paralysis', 'is a type of polyradiculoneuritis seen in Coonhounds. The cause has been related to a raccoon bite.', 'Signs include rear leg weakness progressing rapidly to paralysis, and decreased reflexes.'),
(16, 'Wobbler disease', ' is a condition of the cervical vertebrae that causes an unsteady gait and weakness in dogs.', 'cervical instability');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `number` int(11) NOT NULL,
  `email` varchar(11) NOT NULL,
  `method` varchar(11) NOT NULL,
  `flat` int(11) NOT NULL,
  `street` varchar(11) NOT NULL,
  `city` varchar(11) NOT NULL,
  `state` varchar(11) NOT NULL,
  `country` varchar(11) NOT NULL,
  `pin_code` int(11) NOT NULL,
  `total_products` int(11) NOT NULL,
  `total_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `name`, `number`, `email`, `method`, `flat`, `street`, `city`, `state`, `country`, `pin_code`, `total_products`, `total_price`) VALUES
(0, 'mi', 12, 'myshamomo20', 'credit cart', 125, 'dgsthytdh', 'dgfyhfhm', 'gnjyj', 'gyjyhm', 0, 0, 200),
(0, 'momo', 1554, 'njkuh@gmail', 'credit cart', 21, 'def', 'dwdffddf', 'fwg', 'dsfg', 0, 0, 5),
(0, 'momo', 125, 'momo@gmail.', 'credit cart', 12, 'ssd', 'ssd', 'dsfrg', 'dfsgr', 12000, 0, 2),
(0, 'rhyme', 1545, 'r@gmail.com', 'paypal', 11, 'asdewf', 'fwrg', 'rge', 'rget', 0, 0, 9),
(0, 'Mysha Momo', 1927042032, 'mysha.cse.2', 'credit cart', 0, 'sddf', 'Dhaka', 'dhaka', 'Bangladesh', 1230, 0, 2),
(0, 'Mysha Momo', 1927042032, 'mysha.cse.2', 'credit cart', 0, 'SKS', 'Dhaka', 'Dhaka', 'Bangladesh', 1230, 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `price` int(11) NOT NULL,
  `image` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(0, 'vee', 4, 0x726162342e6a7067),
(0, 'mew', 5, 0x636174322e6a7067),
(0, 'sim', 2, 0x646f67322e6a706567);

-- --------------------------------------------------------

--
-- Table structure for table `vets`
--

CREATE TABLE `vets` (
  `vet_id` int(6) UNSIGNED NOT NULL,
  `vet_name` varchar(30) NOT NULL,
  `vet_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vets`
--

INSERT INTO `vets` (`vet_id`, `vet_name`, `vet_type`) VALUES
(1, 'meherin', 'Dentistry'),
(2, 'rahman', 'Dentistry'),
(3, 'jenny', 'Neurology'),
(4, 'john', 'Neurology'),
(5, 'meher', 'Behaviour'),
(6, 'karin', 'Behaviour'),
(7, 'meherin', 'Nutrition'),
(8, 'mehu', 'Surgery'),
(20, 'meherin', 'Surgery'),
(125555, 'meherin', 'Behaviour');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `encyclopedia`
--
ALTER TABLE `encyclopedia`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `vets`
--
ALTER TABLE `vets`
  ADD PRIMARY KEY (`vet_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `encyclopedia`
--
ALTER TABLE `encyclopedia`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `vets`
--
ALTER TABLE `vets`
  MODIFY `vet_id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125556;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
