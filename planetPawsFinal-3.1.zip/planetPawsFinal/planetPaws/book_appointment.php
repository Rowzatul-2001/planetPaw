<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "planetPaw";
$port=3307;


$conn = new mysqli($servername, $username, $password, $dbname,$port);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_GET['vet_type'])) {
    $vet_type = $_GET['vet_type'];
    $sql = "SELECT vet_name FROM vets WHERE vet_type='$vet_type'";
    $result = $conn->query($sql);
    $vet_names = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $vet_names[] = $row['vet_name'];
        }
    }
    echo json_encode($vet_names);
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pet_age = $_POST['pet_age'];
    $health_issue = $_POST['health_issue'];
    $vet_name = $_POST['vet_name'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];


    $sql_check = "SELECT * FROM appointments WHERE vet_name='$vet_name' AND appointment_date='$appointment_date' AND appointment_time='$appointment_time'";
    $result_check = $conn->query($sql_check);
    if ($result_check->num_rows > 0) {
        echo "<script>alert('This appointment slot is already booked.');</script>";
    } else {
        $sql = "INSERT INTO appointments (pet_age, health_issue, vet_name, appointment_date, appointment_time) VALUES ('$pet_age', '$health_issue', '$vet_name', '$appointment_date', '$appointment_time')";
        if ($conn->query($sql) === TRUE) {
            echo "";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}


$sql = "SELECT * FROM appointments";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Appointment</title>
    <script>
        function fetchVetNames(vetType) {
            fetch(`book_appointment.php?vet_type=${vetType}`)
                .then(response => response.json())
                .then(data => {
                    let vetNameSelect = document.getElementById('vet_name');
                    vetNameSelect.innerHTML = '';
                    data.forEach(name => {
                        let option = document.createElement('option');
                        option.value = name;
                        option.text = name;
                        vetNameSelect.appendChild(option);
                    });
                });
        }





        function disablePastDates() {
            let dateInput = document.getElementById('appointment_date');
            let today = new Date().toISOString().split('T')[0];
            dateInput.setAttribute('min', today);
        }

        document.addEventListener('DOMContentLoaded', disablePastDates);
    </script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#93C572;">
    <div class="container">
        <div class="form-section">
        <a class="me-3 py-2 text-light text-decoration-none btn btn-success " href="home.html">Back to Home page</a>
            <h2>Book Appointment For Your Pets<hr style="background-color:#4CBB17"></h2>
            <form method="post" action="">

    <div class="form-group">
     <label for="pet_age"> Pet Age:</label>
     <input type="number" class="form-control" id="pet_age" name="pet_age" required>
     </div>

     <div class="form-group">
     <label for="health_issue"> Health Issue:</label>
     <input type="text" class="form-control" id="health_issue" name="health_issue" required>
     </div>

     
     <div class="form-group">
     <label for="vet_type"> Vet Type:</label>
     
     <select id="vet_type" name="vet_type" class="form-control" onchange="fetchVetNames(this.value)" required>
     <option value="Dentistry">Dentistry</option>
        <option value="Neurology">Neurology</option>
        <option value="Behaviour">Behaviour</option>
        <option value="Nutrition">Nutrition</option>
        <option value="Surgery">Surgery</option>
        </select> 
     </div>

  
                <div class="form-group">
                Vet Name: <select class="form-control" id="vet_name" name="vet_name" required></select><br>
                <div class="form-group">


                <div class="form-group">
     <label for="appointment_date"> Appointment Date:</label>
     <input type="date" class="form-control" id="appointment_date" name="appointment_date" required>
     </div>

     <label for="appointment_time"> Appointment Time:</label>
     <input type="time" class="form-control" id="appointment_time" name="appointment_time" required>
     </div>
     <input type="submit" <button class="btn btn-success"></button>
     <a class="me-3 py-2 text-light text-decoration-none btn btn-success " href="submit_vet.php">Vets Info</a>
        </div>
        <br>
        <div class="display-section">
            <h2>All the Booked Appointments<hr style="background-color:#4CBB17"></h2><br>
            <table class="table table-bordered" style="background-color:#C1E1C1;">
                <thead>
                    <tr class="table-success">
                        <th>Pet age</th>
                        <th>Health Issue</th>
                        <th>Vet Name</th>
                        <th>Appointment Date</th>
                        <th>Appointment Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>" . $row["pet_age"]. "</td>
                                <td>" . $row["health_issue"]. "</td>
                                 <td>" . $row["vet_name"]. "</td>
                                <td>" . $row["appointment_date"]. "</td>
                                 <td>" . $row["appointment_time"]. "</td>
                            </tr>";
                        }
                    } else {
                        echo "There is no booked appointment ";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
