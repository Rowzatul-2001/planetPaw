<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "planetPaw";
$port=3307;


$conn = new mysqli($servername, $username, $password, $dbname,$port);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vet_id = $_POST['vet_id'];
    $vet_name = $_POST['vet_name'];
    $vet_type = $_POST['vet_type'];

    $sql = "INSERT INTO vets (vet_id, vet_name, vet_type) VALUES ('$vet_id', '$vet_name', '$vet_type')";
    if ($conn->query($sql) === TRUE) {
        echo "";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


$sql = "SELECT * FROM vets";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submit Vet Info</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#93C572;;">
    <div class="container">
        <div class="form-section">
        <a class="me-3 py-2 text-light text-decoration-none btn btn-success " href="home.html">Back to Home page</a>
            <h2>Add a New Vet Member<hr style="background-color:#4CBB17"></h2>
            <form method="post" action="">

            <div class="form-group">
            <label for="vet_id"> veterinarian ID:</label>
            <input type="number" class="form-control" id="vet_id" name="vet_id" required>
             </div>

             <div class="form-group">
            <label for="vet_name"> veterinarian Name:</label>
            <input type="text" class="form-control" id="vet_name" name="vet_name" required>
            </div>

           <div class="form-group">
        <label for="vet_type"> veterinarian Type:</label>
        <select id="vet_type" name="vet_type" class="form-control" required>
        <option value="Dentistry">Dentistry</option>
        <option value="Neurology">Neurology</option>
        <option value="Behaviour">Behaviour</option>
        <option value="Nutrition">Nutrition</option>
        <option value="Surgery">Surgery</option>
        </select> 
        </div>
                <input <button class="btn btn-success" type="submit"></button>
            
            <a class="me-3 py-2 text-light text-decoration-none btn btn-success " href="book_appointment.php">Back to book a appointment</a>
            </form>
        </div>
        <br>
        <div class="display-section">
            <h2>Our All veterinarian members<hr style="background-color:#4CBB17"></h2><br>
             <table class="table table-bordered" style="background-color:#C1E1C1;">
                <thead>
                    <tr class="table-success">
                        <th>veterinarian ID</th>
                        <th>veterinarian name</th>
                        <th>veterinarian type</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr >
                                <td>" . $row["vet_id"]. "</td>
                                <td>" . $row["vet_name"]. "</td>
                                <td>" . $row["vet_type"]. "</td>
                            </tr>";
                        }
                    } else {
                        echo "No saved information about  veterinarian";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
