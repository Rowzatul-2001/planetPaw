<?php

$conn = mysqli_connect('localhost','root','','planetPaw',3307) or die('connection failed');

?>