<header class="header">

   <div class="flex">

      <a href="#" class="logo">Pet Adoption</a>

      <nav class="navbar">
         <a href="admin.php">add pets</a>
         <a href="products.php">view pets</a>
      </nav>

      <?php
      
      $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);

      ?>

      <a href="cart.php" class="cart">cart <span><?php echo $row_count; ?></span> </a>
      <a href="home.html" class="back-btn">back</a>

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>