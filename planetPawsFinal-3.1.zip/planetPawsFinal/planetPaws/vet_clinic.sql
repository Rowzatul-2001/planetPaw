

CREATE TABLE vets (
    vet_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    vet_name VARCHAR(30) NOT NULL,
    vet_type VARCHAR(30) NOT NULL
);

insert into  vets values(1,'meherin','Dentistry');

insert into  vets values(2,'rahman','Dentistry');

insert into  vets values(3,'jenny','Neurology');

insert into  vets values(4,'john','Neurology');

insert into  vets values(5,'meher','Behaviour');

insert into  vets values(6,'karin','Behaviour');

insert into  vets values(7,'meherin','Nutrition');

insert into  vets values(8,'mehu','Surgery');


CREATE TABLE appointments (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pet_age INT NOT NULL,
    health_issue VARCHAR(100) NOT NULL,
    vet_name VARCHAR(30) NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL
);




