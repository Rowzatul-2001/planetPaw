-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 08, 2024 at 04:48 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `planetPaw`
--

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `message` text DEFAULT NULL,
  `donation_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `name`, `email`, `amount`, `message`, `donation_date`) VALUES
(1, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 10.00, 'wweffqe', '2024-06-29 06:53:58'),
(2, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:19:47'),
(3, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:21:46'),
(4, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:22:02'),
(5, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 30.00, 'wdfcerg4tg4', '2024-06-29 07:23:52'),
(6, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:25:39'),
(7, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:26:13'),
(8, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:26:54'),
(9, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:27:05'),
(10, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:27:14'),
(11, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'dwfeferfref', '2024-06-29 07:27:23'),
(12, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 40.00, 'fefergt34gtgh', '2024-06-29 07:28:11'),
(14, 'Rowzatul Zannath Prerona', 'rowzatulzannathprerona@gmail.com', 100.00, 'nekjfnjerfnerjgerjgejr', '2024-06-29 15:44:01'),
(15, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 1000.00, 'jefhejrfhreufhuer', '2024-06-30 03:07:43'),
(16, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 1000.00, 'jvbejrverhgbh', '2024-06-30 03:08:57'),
(17, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 200.00, 'enfdejfnerjferj', '2024-06-30 03:45:44'),
(18, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 200.00, 'enfdejfnerjferj', '2024-06-30 03:45:50'),
(19, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 10000.00, 'wydgeyfgeryfgeyrf', '2024-06-30 04:10:52'),
(20, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 10000.00, 'private donate', '2024-06-30 07:43:45'),
(21, 'Rowzatul Zannath', 'rowzatulzannathprerona@gmail.com', 1000.00, 'jdbjewbjwfwjf', '2024-07-08 14:39:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
