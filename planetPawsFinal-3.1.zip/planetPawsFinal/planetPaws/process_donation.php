<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "planetPaw";
$port=3307;

$conn = new mysqli($servername, $username, $password, $dbname,3307);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("INSERT INTO donations (name, email, amount, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssds", $name, $email, $amount, $message);

$name = $_POST['name'];
$email = $_POST['email'];
$amount = $_POST['amount'];
$message = $_POST['message'];

if ($stmt->execute()) {
    echo "<h2 style='color: green; text-align: center; margin-top: 300px;'>Thank you for your donation!</h2>";
    echo '<button style="background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    margin-left: 630px ;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin-top: 20px;
    cursor: pointer;
    border-radius: 5px;"
    onclick="window.location.href = \'home.html\';">Back to Home</button>';
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
